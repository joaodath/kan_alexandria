.. _todo:

TODO:
=====

__main__.py
------------
* Decouple Book interface and implementation


models.py
----------
* Handle display operations here rather than in main


structures.py
-------------
* Simplify API call using filters
